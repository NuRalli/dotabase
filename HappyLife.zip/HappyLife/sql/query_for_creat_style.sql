--------------------------------------------------------
--  File created - Sunday-December-13-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table STYLES
--------------------------------------------------------

  CREATE TABLE "ZHAN"."STYLES" 
   (	"STYLE_ID" NUMBER(11,0), 
	"STYLE_NAME" VARCHAR2(255 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index PK_STYLE
--------------------------------------------------------

  CREATE UNIQUE INDEX "ZHAN"."PK_STYLE" ON "ZHAN"."STYLES" ("STYLE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Trigger STYLES_TRIGGER
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "ZHAN"."STYLES_TRIGGER" BEFORE
  INSERT ON styles
  FOR EACH ROW
DECLARE
  v_count NUMBER;
BEGIN
  SELECT
    COUNT(*)
  INTO v_count
  FROM
    styles
  WHERE
    style_name = :new.style_name;

  IF v_count > 0 THEN
    raise_application_error(-20500, 'Duplicate style');
  END IF;
END;
/
ALTER TRIGGER "ZHAN"."STYLES_TRIGGER" ENABLE;
--------------------------------------------------------
--  Constraints for Table STYLES
--------------------------------------------------------

  ALTER TABLE "ZHAN"."STYLES" ADD CONSTRAINT "PK_STYLE" PRIMARY KEY ("STYLE_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "ZHAN"."STYLES" MODIFY ("STYLE_NAME" NOT NULL ENABLE);
