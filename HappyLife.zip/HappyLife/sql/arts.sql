--------------------------------------------------------
--  File created - �����-������-14-2021   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ARTS
--------------------------------------------------------

  CREATE TABLE "TEST"."ARTS" 
   (	"ARTS_ID" NUMBER(*,0), 
	"TITLE" VARCHAR2(255 BYTE), 
	"PRICE" VARCHAR2(100 BYTE), 
	"STYLE" VARCHAR2(255 BYTE), 
	"IMAGE" VARCHAR2(255 BYTE), 
	"AUTHOR" VARCHAR2(255 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into TEST.ARTS
SET DEFINE OFF;
Insert into TEST.ARTS (ARTS_ID,TITLE,PRICE,STYLE,IMAGE,AUTHOR) values ('48','my art','100','portrait','a.img','Bolat Zhanserik');
Insert into TEST.ARTS (ARTS_ID,TITLE,PRICE,STYLE,IMAGE,AUTHOR) values ('49','my art','100','portrait','a.img','Bolat Zhanserik');
Insert into TEST.ARTS (ARTS_ID,TITLE,PRICE,STYLE,IMAGE,AUTHOR) values ('1','Blue portrait','100','portrait','blue-portrait-eve-ventrue.jpg','Eve Ventrue');
Insert into TEST.ARTS (ARTS_ID,TITLE,PRICE,STYLE,IMAGE,AUTHOR) values ('2','Killer','100','portrait','killer-joe-douglas-simonson 2013.jpg','Douglas Simonson');
Insert into TEST.ARTS (ARTS_ID,TITLE,PRICE,STYLE,IMAGE,AUTHOR) values ('3','Moon Landing','100','graphic art','Moon Landing 2019.jpg','James Round');
Insert into TEST.ARTS (ARTS_ID,TITLE,PRICE,STYLE,IMAGE,AUTHOR) values ('4','"Artistin ernst"','100','genre art','artistin-ernst-ludwig-kirchner-genre art.jpg','Ludwig Kirchner');
Insert into TEST.ARTS (ARTS_ID,TITLE,PRICE,STYLE,IMAGE,AUTHOR) values ('5','Eyes','100','graphic art','Hawokaii.jpg','Hawokaii');
Insert into TEST.ARTS (ARTS_ID,TITLE,PRICE,STYLE,IMAGE,AUTHOR) values ('6','Mens room','100','Genre art','mens-room-scott-listfield.jpg','Scott listfield');
Insert into TEST.ARTS (ARTS_ID,TITLE,PRICE,STYLE,IMAGE,AUTHOR) values ('7','Headger','100','graphic','Headger - Matt Griffin.jpg','Matt Griffin');
Insert into TEST.ARTS (ARTS_ID,TITLE,PRICE,STYLE,IMAGE,AUTHOR) values ('8','Zhanserik','40','portrait','einstein-harold-belarmino.jpg','Bolat Zhanserik');
Insert into TEST.ARTS (ARTS_ID,TITLE,PRICE,STYLE,IMAGE,AUTHOR) values ('9','Nicolas Cage','200','portrait','nicolas-cage-a-vampires-kiss-olga-shvartsur.jpg','Bolat Zhanserik');
--------------------------------------------------------
--  DDL for Index ARTS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "TEST"."ARTS_PK" ON "TEST"."ARTS" ("ARTS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table ARTS
--------------------------------------------------------

  ALTER TABLE "TEST"."ARTS" ADD CONSTRAINT "ARTS_PK" PRIMARY KEY ("ARTS_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
  ALTER TABLE "TEST"."ARTS" MODIFY ("AUTHOR" NOT NULL ENABLE);
  ALTER TABLE "TEST"."ARTS" MODIFY ("IMAGE" NOT NULL ENABLE);
  ALTER TABLE "TEST"."ARTS" MODIFY ("STYLE" NOT NULL ENABLE);
  ALTER TABLE "TEST"."ARTS" MODIFY ("PRICE" NOT NULL ENABLE);
  ALTER TABLE "TEST"."ARTS" MODIFY ("TITLE" NOT NULL ENABLE);
  ALTER TABLE "TEST"."ARTS" MODIFY ("ARTS_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  DDL for Trigger AUTO_INC
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TEST"."AUTO_INC" 
   before insert on "TEST"."ARTS" 
   for each row 
begin  
   if inserting then 
      if :NEW."ARTS_ID" is null then 
         select SEQUENCE1.nextval into :NEW."ARTS_ID" from dual; 
      end if; 
   end if; 
end;

/
ALTER TRIGGER "TEST"."AUTO_INC" ENABLE;
